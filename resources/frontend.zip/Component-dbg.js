sap.ui.define(["sap/fe/core/AppComponent"], function(AppComponent) {
    'use strict';

    return AppComponent.extend("frontend.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
